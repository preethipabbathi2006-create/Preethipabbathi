import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt

def manual_mean(data):
    return sum(data) / len(data)

def manual_variance(data):
    mean = manual_mean(data)
    return sum((x - mean) ** 2 for x in data) / len(data)

def execution_time(func, data):
    times = []
    for _ in range(10):
        start = time.time()
        func(data)

        times.append(time.time() - start)
    return sum(times) / len(times)

def main():
    df = pd.read_excel(R"c:\Users\preet\Downloads\Lab Session Data.xlsx", sheet_name="IRCTC Stock Price")
    price = df["Price"].values

    print("Mean (Numpy):", np.mean(price))
    print("Variance (Numpy):", np.var(price))
    print("Mean (Manual):", manual_mean(price))
    print("Variance (Manual):", manual_variance(price))

    print("Manual Mean Time:", execution_time(manual_mean, price))
    print("Numpy Mean Time:", execution_time(np.mean, price))

    wednesday_mean = df[df["Day"] == "Wednesday"]["Price"].mean()
    april_mean = df[df["Month"] == "Apr"]["Price"].mean()

    print("Wednesday Mean:", wednesday_mean)
    print("April Mean:", april_mean)

    loss_prob = len(df[df["Chg%"] < 0]) / len(df)
    print("Probability of Loss:", loss_prob)

    wed_profit = df[(df["Day"] == "Wednesday") & (df["Chg%"] > 0)]
    print("Profit on Wednesday Probability:", len(wed_profit) / len(df))

    plt.scatter(df["Day"], df["Chg%"])
    plt.xlabel("Day")
    plt.ylabel("Change%")
    plt.show()

main()

    
    
