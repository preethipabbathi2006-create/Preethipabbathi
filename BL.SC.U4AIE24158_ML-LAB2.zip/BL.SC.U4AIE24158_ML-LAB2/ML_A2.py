import pandas as pd

def classify_customers(df):
    return ["RICH" if p > 200 else "POOR" for p in df["Payment (Rs)"]]

def main():
    df = pd.read_excel(r"C:\Users\preet\Downloads\Lab Session Data.xlsx", sheet_name="Purchase data")
    df["Status"] = classify_customers(df)
    print(df[["Payment (Rs)", "Status"]])

main()
    
                                            
                                                      
                                                      
