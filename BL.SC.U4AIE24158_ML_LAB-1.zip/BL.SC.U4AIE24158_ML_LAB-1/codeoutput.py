Python 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
======================== RESTART: C:/Users/preet/code.py =======================
Enter a string:preethi
Numbers of vowels: 3
Number of consonants: 4
Matrix multiplication result:
[19, 22]
[43, 50]
Number of common elements: 3
Transpose of matrix:
[1, 4]
[2, 5]
[3, 6]
Mean: 125.9
Median: 126.0
Mode: 136
